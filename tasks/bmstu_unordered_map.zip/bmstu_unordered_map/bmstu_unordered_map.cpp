#include <bmstu_unordered_map.h>
#include <gtest/gtest.h>
#include <stdexcept>
#include <string>
#include <vector>

using namespace std::string_literals;

// Переименовали тестовый набор
#define TEST_SUITE UnorderedMapTests

TEST(TEST_SUITE, EmptyContainerCreation)
{
	// Проверка базового конструктора
	bmstu::unordered_map<char, double> dict;
	ASSERT_TRUE(dict.empty());
	ASSERT_EQ(dict.size(), 0);
	ASSERT_GT(dict.bucket_count(),
			  0);  // Проверяем просто что корзины выделились

	// Проверка конструктора с заданной вместимостью
	bmstu::unordered_map<std::string, std::string> str_dict(32);
	ASSERT_TRUE(str_dict.empty());
	ASSERT_EQ(str_dict.bucket_count(), 32);
}

TEST(TEST_SUITE, ElementAccessViaBrackets)
{
	bmstu::unordered_map<std::string, std::string> colors;

	// Вставка через скобки
	colors["red"] = "#FF0000";
	colors["green"] = "#00FF00";

	ASSERT_EQ(colors.size(), 2);
	ASSERT_EQ(colors["red"], "#FF0000");

	// Перезапись
	colors["red"] = "changed_color";
	ASSERT_EQ(colors["red"], "changed_color");

	// Обращение к несуществующему ключу должно создать пустой элемент
	ASSERT_EQ(colors["blue"], "");
	ASSERT_EQ(colors.size(), 3);
}

TEST(TEST_SUITE, AddAndSearch)
{
	bmstu::unordered_map<int, double> grades;
	grades.insert(101, 4.5);
	grades.insert(102, 3.8);
	grades.insert(103, 5.0);

	ASSERT_FALSE(grades.empty());
	ASSERT_EQ(grades.size(), 3);

	// Поиск существующего
	auto iter = grades.find(102);
	ASSERT_NE(iter, grades.end());
	ASSERT_EQ(iter->second, 3.8);

	// Метод contains
	ASSERT_TRUE(grades.contains(101));
	ASSERT_FALSE(grades.contains(999));

	// Поиск несуществующего
	auto missing = grades.find(404);
	ASSERT_EQ(missing, grades.end());
}

TEST(TEST_SUITE, RemoveElements)
{
	bmstu::unordered_map<int, int> nums;
	for (int i = 1; i <= 5; ++i)
	{
		nums[i] = i * 10;  // 1->10, 2->20...
	}

	ASSERT_EQ(nums.size(), 5);

	// Удаляем из середины
	nums.erase(3);
	ASSERT_FALSE(nums.contains(3));
	ASSERT_EQ(nums.size(), 4);

	// Удаление несуществующего ключа не должно ломать прогу
	nums.erase(100);
	ASSERT_EQ(nums.size(), 4);

	// Удаляем всё остальное
	nums.erase(1);
	nums.erase(2);
	nums.erase(4);
	nums.erase(5);

	ASSERT_TRUE(nums.empty());
}

TEST(TEST_SUITE, WipeAllData)
{
	bmstu::unordered_map<int, std::string> table;

	for (int i = 0; i < 50; ++i)
	{
		table[i] = "Data " + std::to_string(i);
	}

	ASSERT_FALSE(table.empty());

	table.clear();

	ASSERT_TRUE(table.empty());
	ASSERT_EQ(table.size(), 0);
	ASSERT_FALSE(table.contains(25));
}

TEST(TEST_SUITE, CopySemantics)
{
	bmstu::unordered_map<int, std::string> src;
	src[1] = "Alice";
	src[2] = "Bob";

	// Тест конструктора копирования
	bmstu::unordered_map<int, std::string> dest_constructed(src);
	ASSERT_EQ(dest_constructed.size(), 2);
	ASSERT_EQ(dest_constructed[1], "Alice");

	// Тест оператора присваивания
	bmstu::unordered_map<int, std::string> dest_assigned;
	dest_assigned = src;
	ASSERT_EQ(dest_assigned.size(), 2);

	// Проверка независимости памяти
	src[1] = "Charlie";
	ASSERT_EQ(dest_constructed[1], "Alice");
	ASSERT_EQ(dest_assigned[1], "Alice");
}

TEST(TEST_SUITE, MoveSemantics)
{
	bmstu::unordered_map<int, int> src1;
	src1[10] = 100;

	// Перемещающий конструктор
	bmstu::unordered_map<int, int> dest1(std::move(src1));
	ASSERT_EQ(dest1.size(), 1);
	ASSERT_TRUE(src1.empty());	// Оригинал должен обнулиться
	ASSERT_EQ(dest1[10], 100);

	bmstu::unordered_map<int, int> src2;
	src2[20] = 200;

	// Перемещающее присваивание
	bmstu::unordered_map<int, int> dest2;
	dest2 = std::move(src2);
	ASSERT_EQ(dest2.size(), 1);
	ASSERT_TRUE(src2.empty());
}

TEST(TEST_SUITE, CompareAndSwap)
{
	bmstu::unordered_map<int, int> m1 = {{1, 10}, {2, 20}};
	bmstu::unordered_map<int, int> m2 = {{2, 20}, {1, 10}};	 // Другой порядок
	bmstu::unordered_map<int, int> m3 = {{3, 30}};

	ASSERT_TRUE(m1 == m2);
	ASSERT_FALSE(m1 == m3);
	ASSERT_TRUE(m1 != m3);

	auto m1_size = m1.size();
	auto m3_size = m3.size();

	// Меняем местами
	m1.swap(m3);

	ASSERT_EQ(m1.size(), m3_size);
	ASSERT_EQ(m3.size(), m1_size);
	ASSERT_TRUE(m1.contains(3));
	ASSERT_TRUE(m3.contains(1));
}

TEST(TEST_SUITE, ForwardIteration)
{
	bmstu::unordered_map<int, int> map;
	int expected_sum = 0;

	for (int i = 1; i <= 15; ++i)
	{
		map[i] = i * 2;
		expected_sum += (i * 2);
	}

	// Проход через range-based for
	int actual_sum = 0;
	for (const auto& pair : map)
	{
		actual_sum += pair.second;
	}
	ASSERT_EQ(actual_sum, expected_sum);

	// Проход через явные итераторы
	actual_sum = 0;
	for (auto it = map.begin(); it != map.end(); ++it)
	{
		actual_sum += it->second;
	}
	ASSERT_EQ(actual_sum, expected_sum);
}

TEST(TEST_SUITE, CapacityGrowthOnLoad)
{
	bmstu::unordered_map<int, int> map(8);
	auto initial_cap = map.bucket_count();

	// Забиваем таблицу так, чтобы точно вызвался rehash
	for (int i = 0; i < 500; ++i)
	{
		map.insert(i, i * i);
	}

	ASSERT_GT(map.bucket_count(), initial_cap);
	ASSERT_EQ(map.size(), 500);

	// Проверяем, что элементы выжили после рехеша
	ASSERT_TRUE(map.contains(250));
	ASSERT_EQ(map[10], 100);
}

TEST(TEST_SUITE, ExceptionOnAtMethod)
{
	bmstu::unordered_map<std::string, int> map;
	map["test"] = 42;

	ASSERT_EQ(map.at("test"), 42);

	// Должно бросить исключение out_of_range
	ASSERT_THROW(map.at("missing_key"), std::out_of_range);

	// Проверка работы at() для константной мапы
	const auto& const_map = map;
	ASSERT_EQ(const_map.at("test"), 42);
	ASSERT_THROW(const_map.at("missing_key"), std::out_of_range);
}

TEST(TEST_SUITE, EdgeCasesWithEmptyMap)
{
	bmstu::unordered_map<int, std::string> map;

	// Ничего не должно падать при работе с пустым контейнером
	ASSERT_EQ(map.find(777), map.end());
	ASSERT_FALSE(map.contains(777));
	map.erase(777);

	ASSERT_TRUE(map.empty());

	// Сразу вставляем
	map[777] = "Lucky";
	ASSERT_EQ(map.size(), 1);
	ASSERT_EQ(map[777], "Lucky");
}

TEST(TEST_SUITE, HighLoadPerformanceData)
{
	bmstu::unordered_map<int, int> map;
	const int limit = 8192;	 // Используем степень двойки вместо 10000

	for (int i = 0; i < limit; ++i)
	{
		map[i] = i;
	}

	ASSERT_EQ(map.size(), limit);

	// Удаляем все четные ключи
	for (int i = 0; i < limit; i += 2)
	{
		map.erase(i);
	}

	ASSERT_EQ(map.size(), limit / 2);

	for (int i = 0; i < limit; ++i)
	{
		if (i % 2 == 0)
		{
			ASSERT_FALSE(map.contains(i));
		}
		else
		{
			ASSERT_TRUE(map.contains(i));
		}
	}
}