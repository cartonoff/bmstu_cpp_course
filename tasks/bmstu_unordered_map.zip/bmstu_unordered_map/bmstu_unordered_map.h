#pragma once

#include <algorithm>
#include <cstddef>
#include <functional>
#include <stdexcept>
#include <utility>
#include <vector>

namespace bmstu
{

template <typename Key, typename Value, typename Hash = std::hash<Key>>
class unordered_map
{
   public:
	// Псевдонимы типов
	using key_type = Key;
	using mapped_type = Value;
	using value_type = std::pair<const Key, Value>;
	using size_type = std::size_t;
	using hasher = Hash;

   private:
	// Узел связного списка
	struct Node
	{
		value_type data;
		// Кэшированный хэш для оптимизации
		size_type cached_hash;
		Node* next;

		// Конструктор копирования ноды
		Node(size_type hash, const key_type& k, const mapped_type& v)
			: data(k, v), cached_hash(hash), next(nullptr)
		{
		}

		// Конструктор перемещения ноды
		Node(size_type hash, key_type&& k, mapped_type&& v)
			: data(std::move(k), std::move(v)), cached_hash(hash), next(nullptr)
		{
		}

		// Комбинированный: копирует ключ, но перемещает тяжелое значение
		Node(size_type hash, const key_type& k, mapped_type&& v)
			: data(k, std::move(v)), cached_hash(hash), next(nullptr)
		{
		}
	};

	std::vector<Node*> table_;
	size_type elements_count_;
	hasher hash_func_;
	float max_load_;

	// Быстрое получение индекса по хешу
	size_type bucket_for_hash(size_type h, size_type capacity) const
	{
		return capacity > 0 ? h % capacity : 0;
	}

	float current_load_factor() const
	{
		return table_.empty()
				   ? 0.0f
				   : static_cast<float>(elements_count_) / table_.size();
	}

	// Быстрое копирование цепочки (без пересчета хешей) для конструктора
	// копирования
	Node* copy_chain(Node* head)
	{
		if (!head)
			return nullptr;
		Node* new_head =
			new Node(head->cached_hash, head->data.first, head->data.second);
		Node* curr_new = new_head;
		Node* curr_old = head->next;

		while (curr_old)
		{
			curr_new->next =
				new Node(curr_old->cached_hash, curr_old->data.first,
						 curr_old->data.second);
			curr_new = curr_new->next;
			curr_old = curr_old->next;
		}
		return new_head;
	}

	// Внутренняя реализация вставки через perfect forwarding
	template <typename KType, typename VType>
	void insert_impl(KType&& k, VType&& v)
	{
		if (table_.empty() || current_load_factor() >= max_load_)
		{
			rehash(table_.empty() ? 16 : table_.size() * 2);
		}

		size_type h = hash_func_(k);
		size_type idx = bucket_for_hash(h, table_.size());

		Node* curr = table_[idx];
		while (curr)
		{
			if (curr->cached_hash == h && curr->data.first == k)
			{
				curr->data.second = std::forward<VType>(v);
				return;
			}
			curr = curr->next;
		}

		Node* new_node =
			new Node(h, std::forward<KType>(k), std::forward<VType>(v));
		new_node->next = table_[idx];
		table_[idx] = new_node;
		++elements_count_;
	}

   public:
	// Единый шаблон для iterator и const_iterator (избавляет от дублирования
	// кода)
	template <bool IsConst>
	class hash_iterator
	{
	   public:
		using iterator_category = std::forward_iterator_tag;
		using value_type = unordered_map::value_type;
		using difference_type = std::ptrdiff_t;
		using pointer =
			std::conditional_t<IsConst, const value_type*, value_type*>;
		using reference =
			std::conditional_t<IsConst, const value_type&, value_type&>;

	   private:
		using NodePtr = std::conditional_t<IsConst, const Node*, Node*>;
		using MapPtr = const unordered_map*;

		NodePtr node_;
		MapPtr map_;

		// Nested class has automatic access to private members of unordered_map
		hash_iterator(NodePtr n, MapPtr m) : node_(n), map_(m) {}

		friend class unordered_map;

	   public:
		hash_iterator() : node_(nullptr), map_(nullptr) {}

		// Конструктор преобразования обычного итератора в константный
		template <bool WasConst = IsConst,
				  typename = std::enable_if_t<IsConst && !WasConst>>
		hash_iterator(const hash_iterator<false>& other)
			: node_(other.node_), map_(other.map_)
		{
		}

		reference operator*() const { return node_->data; }
		pointer operator->() const { return &(node_->data); }

		hash_iterator& operator++()
		{
			if (!node_)
				return *this;

			if (node_->next)
			{
				node_ = node_->next;
			}
			else
			{
				// Если цепочка закончилась, вычисляем индекс текущей корзины и
				// ищем следующую
				size_type current_idx = map_->bucket_for_hash(
					node_->cached_hash, map_->table_.size());
				node_ = nullptr;
				for (size_type i = current_idx + 1; i < map_->table_.size();
					 ++i)
				{
					if (map_->table_[i])
					{
						node_ = map_->table_[i];
						break;
					}
				}
			}
			return *this;
		}

		hash_iterator operator++(int)
		{
			hash_iterator tmp = *this;
			++(*this);
			return tmp;
		}

		bool operator==(const hash_iterator& other) const
		{
			return node_ == other.node_;
		}
		bool operator!=(const hash_iterator& other) const
		{
			return node_ != other.node_;
		}
	};

	using iterator = hash_iterator<false>;
	using const_iterator = hash_iterator<true>;

	// ------------------------------------------
	// КОНСТРУКТОРЫ И ДЕСТРУКТОР
	// ------------------------------------------

	unordered_map() : elements_count_(0), max_load_(0.75f)
	{
		table_.resize(16, nullptr);
	}

	explicit unordered_map(size_type bucket_count)
		: elements_count_(0), max_load_(0.75f)
	{
		table_.resize(bucket_count > 0 ? bucket_count : 16, nullptr);
	}

	unordered_map(std::initializer_list<value_type> init) : unordered_map()
	{
		for (const auto& kv : init)
		{
			insert(kv.first, kv.second);
		}
	}

	template <typename InputIt>
	unordered_map(InputIt first, InputIt last) : unordered_map()
	{
		for (auto it = first; it != last; ++it)
		{
			insert(it->first, it->second);
		}
	}

	// Копирование: быстрое прямое клонирование памяти
	unordered_map(const unordered_map& other)
		: table_(other.table_.size(), nullptr),
		  elements_count_(other.elements_count_),
		  hash_func_(other.hash_func_),
		  max_load_(other.max_load_)
	{
		for (size_type i = 0; i < other.table_.size(); ++i)
		{
			table_[i] = copy_chain(other.table_[i]);
		}
	}

	unordered_map(unordered_map&& other) noexcept
		: table_(std::move(other.table_)),
		  elements_count_(std::exchange(other.elements_count_, 0)),
		  hash_func_(std::move(other.hash_func_)),
		  max_load_(other.max_load_)
	{
	}

	~unordered_map() { clear(); }

	// Универсальный оператор присваивания (Copy-and-Swap Idiom)
	unordered_map& operator=(unordered_map other) noexcept
	{
		swap(other);
		return *this;
	}

	void swap(unordered_map& other) noexcept
	{
		table_.swap(other.table_);
		std::swap(elements_count_, other.elements_count_);
		std::swap(max_load_, other.max_load_);
	}

	friend void swap(unordered_map& lhs, unordered_map& rhs) { lhs.swap(rhs); }

	// ------------------------------------------
	// ОСНОВНОЙ ИНТЕРФЕЙС
	// ------------------------------------------

	void insert(const key_type& key, const mapped_type& value)
	{
		insert_impl(key, value);
	}

	void insert(key_type&& key, mapped_type&& value)
	{
		insert_impl(std::move(key), std::move(value));
	}

	mapped_type& operator[](const key_type& key)
	{
		if (table_.empty() || current_load_factor() >= max_load_)
		{
			rehash(std::max<size_type>(16, table_.size() * 2));
		}

		size_type h = hash_func_(key);
		size_type idx = bucket_for_hash(h, table_.size());

		Node* curr = table_[idx];
		while (curr)
		{
			if (curr->cached_hash == h && curr->data.first == key)
			{
				return curr->data.second;
			}
			curr = curr->next;
		}

		Node* new_node = new Node(h, key, mapped_type());
		new_node->next = table_[idx];
		table_[idx] = new_node;
		++elements_count_;

		return new_node->data.second;
	}

	const mapped_type& at(const key_type& key) const
	{
		auto it = find(key);
		if (it == end())
		{
			throw std::out_of_range("Key missing in unordered_map");
		}
		return it->second;
	}

	void erase(const key_type& key)
	{
		if (table_.empty())
			return;

		size_type h = hash_func_(key);
		size_type idx = bucket_for_hash(h, table_.size());

		Node* curr = table_[idx];
		Node* prev = nullptr;

		while (curr)
		{
			if (curr->cached_hash == h && curr->data.first == key)
			{
				if (prev)
				{
					prev->next = curr->next;
				}
				else
				{
					table_[idx] = curr->next;
				}
				delete curr;
				--elements_count_;
				return;
			}
			prev = curr;
			curr = curr->next;
		}
	}

	void rehash(size_type new_buckets)
	{
		new_buckets = std::max<size_type>(16, new_buckets);
		std::vector<Node*> new_table(new_buckets, nullptr);

		for (Node* curr : table_)
		{
			while (curr)
			{
				Node* next_node = curr->next;
				size_type new_idx =
					bucket_for_hash(curr->cached_hash, new_buckets);

				curr->next = new_table[new_idx];
				new_table[new_idx] = curr;

				curr = next_node;
			}
		}
		table_ = std::move(new_table);
	}

	iterator find(const key_type& key)
	{
		if (table_.empty())
			return end();

		size_type h = hash_func_(key);
		size_type idx = bucket_for_hash(h, table_.size());

		Node* curr = table_[idx];
		while (curr)
		{
			// Быстрая проверка по хешу перед дорогим сравнением ключей
			if (curr->cached_hash == h && curr->data.first == key)
			{
				return iterator(curr, this);
			}
			curr = curr->next;
		}
		return end();
	}

	const_iterator find(const key_type& key) const
	{
		if (table_.empty())
			return end();

		size_type h = hash_func_(key);
		size_type idx = bucket_for_hash(h, table_.size());

		Node* curr = table_[idx];
		while (curr)
		{
			if (curr->cached_hash == h && curr->data.first == key)
			{
				return const_iterator(curr, this);
			}
			curr = curr->next;
		}
		return end();
	}

	bool contains(const key_type& key) const { return find(key) != end(); }

	size_type size() const noexcept { return elements_count_; }
	bool empty() const noexcept { return elements_count_ == 0; }
	size_type bucket_count() const noexcept { return table_.size(); }

	void clear()
	{
		for (auto& head : table_)
		{
			while (head)
			{
				Node* trash = head;
				head = head->next;
				delete trash;
			}
		}
		elements_count_ = 0;
	}

	// ------------------------------------------
	// ИТЕРАЦИЯ
	// ------------------------------------------

	iterator begin()
	{
		for (Node* head : table_)
		{
			if (head)
				return iterator(head, this);
		}
		return end();
	}

	iterator end() { return iterator(nullptr, this); }

	const_iterator begin() const
	{
		for (Node* head : table_)
		{
			if (head)
				return const_iterator(head, this);
		}
		return end();
	}

	const_iterator end() const { return const_iterator(nullptr, this); }

	const_iterator cbegin() const { return begin(); }
	const_iterator cend() const { return end(); }

	// ------------------------------------------
	// СРАВНЕНИЕ
	// ------------------------------------------

	friend bool operator==(const unordered_map& lhs, const unordered_map& rhs)
	{
		if (lhs.size() != rhs.size())
			return false;

		for (const auto& kv : lhs)
		{
			auto it = rhs.find(kv.first);
			if (it == rhs.end() || it->second != kv.second)
			{
				return false;
			}
		}
		return true;
	}

	friend bool operator!=(const unordered_map& lhs, const unordered_map& rhs)
	{
		return !(lhs == rhs);
	}
};

}  // namespace bmstu